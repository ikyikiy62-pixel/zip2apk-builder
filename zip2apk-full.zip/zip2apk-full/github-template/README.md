# zip2apk-builder (template repo)

Ini bukan aplikasi yang kamu jalankan sendiri — ini "bengkel"-nya. Push
folder ini apa adanya ke repo GitHub baru, sambungkan ke website ZIP2APK
kamu di Vercel, dan setelah itu semua build APK akan otomatis lewat sini.

## Cara pakai

1. Buat repo baru di GitHub (public atau private, dua-duanya bisa),
   misal namanya `zip2apk-builder`.
2. Push semua isi folder ini ke repo tersebut:
   ```
   git init
   git add .
   git commit -m "init zip2apk builder"
   git branch -M main
   git remote add origin https://github.com/USERNAME/zip2apk-builder.git
   git push -u origin main
   ```
3. Buat Personal Access Token (fine-grained) khusus untuk repo ini, izinnya:
   - Contents: Read & write
   - Actions: Read & write
4. Di project Vercel (website ZIP2APK kamu), isi Environment Variables:
   ```
   GH_TOKEN=token_dari_langkah_3
   GH_OWNER=username_github_kamu
   GH_REPO=zip2apk-builder
   ```
5. Redeploy Vercel. Selesai — form di halaman Konversi sekarang akan
   benar-benar memicu build APK lewat GitHub Actions di repo ini.

## Cara kerja workflow

`.github/workflows/build.yml` menunggu event `repository_dispatch` dengan
tipe `build-apk`. Event ini dikirim oleh API route `/api/convert` di
website ZIP2APK. Payload-nya berisi nama aplikasi, package id, dan
sumber (link website atau path file ZIP yang sudah diupload ke repo ini).

Workflow lalu:
1. Menyiapkan source (download ZIP dari repo, atau simpan info URL)
2. Menulis nama aplikasi ke `strings.xml`
3. Build APK debug pakai Gradle
4. Membuat GitHub Release dengan tag `build-<id>` dan mengunggah APK
   sebagai asset di situ

Website ZIP2APK lalu polling release dengan tag itu sampai asset APK-nya
muncul, baru menampilkan tombol unduh ke pengguna.

## Yang perlu kamu tahu

- **APK hasil build ditandatangani dengan debug key**, bukan untuk
  dipublikasikan ke Play Store. Kalau butuh signing rilis, tambahkan
  langkah signing dengan keystore kamu sendiri di `build.yml`.
- Proyek Android di sini sengaja minimal (cuma WebView). Kalau butuh
  ikon custom, splash screen, atau fitur native lain, edit langsung
  file-file di `app/src/main/`.
- `gradle-wrapper.jar` sengaja tidak disertakan (butuh biner yang tidak
  bisa dibuat secara manual). Workflow di sini pakai
  `gradle/actions/setup-gradle` yang menginstal Gradle langsung di
  runner, jadi kamu tidak perlu wrapper. Kalau mau develop/test build
  ini di komputer sendiri, jalankan `gradle wrapper` sekali dulu di
  folder ini untuk generate wrapper-nya.
