# ZIP2APK — paket lengkap

- frontend/         -> website Next.js (deploy ke Vercel), tema neobrutalism
- github-template/  -> repo template GitHub Actions yang benar-benar build APK

Baca frontend/app/docs/page.js (atau buka halaman /docs di website setelah
deploy) untuk panduan setup lengkapnya. Ringkasnya:

1. Deploy folder frontend/ ke Vercel
2. Push folder github-template/ ke repo GitHub baru
3. Isi GH_TOKEN, GH_OWNER, GH_REPO di Environment Variables Vercel
4. Redeploy
