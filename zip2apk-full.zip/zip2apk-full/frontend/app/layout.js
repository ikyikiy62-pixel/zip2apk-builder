import "./globals.css";
import Nav from "./components/Nav";

export const metadata = {
  title: "ZIP2APK — Bungkus web jadi APK",
  description: "Upload ZIP atau tempel link website, dapatkan file APK."
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Archivo+Black&family=IBM+Plex+Mono:wght@400;500;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <Nav />
        {children}
        <footer className="footer">
          <div className="wrap">
            ZIP2APK — bungkus situs jadi aplikasi Android. Dibangun di atas
            Next.js dan GitHub Actions.
          </div>
        </footer>
      </body>
    </html>
  );
}
