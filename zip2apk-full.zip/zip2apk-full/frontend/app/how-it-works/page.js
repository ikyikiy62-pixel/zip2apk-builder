export default function HowItWorks() {
  return (
    <main>
      <section className="hero" style={{ padding: "56px 0 40px" }}>
        <div className="wrap">
          <span className="stamp">Manifest Proses</span>
          <h1 style={{ marginTop: 16, fontSize: 42 }}>Cara kerja ZIP2APK</h1>
          <p className="hero-sub">
            Vercel tidak bisa mengompilasi APK secara langsung — proses itu
            berat dan butuh Android SDK penuh. Jadi ZIP2APK memakai GitHub
            Actions sebagai "bengkel" yang benar-benar merakit APK-nya.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="wrap">
          <div className="grid-3">
            <div className="card">
              <div className="card-number">01</div>
              <h3 style={{ fontSize: 18 }}>Kirim</h3>
              <p style={{ fontSize: 14, marginTop: 8 }}>
                Kamu isi form di halaman Konversi: nama aplikasi, dan sumbernya
                (ZIP atau link website).
              </p>
            </div>
            <div className="card">
              <div className="card-number">02</div>
              <h3 style={{ fontSize: 18 }}>Trigger</h3>
              <p style={{ fontSize: 14, marginTop: 8 }}>
                Server ZIP2APK memicu workflow di repo GitHub kamu lewat
                GitHub API, membawa data sumber tadi.
              </p>
            </div>
            <div className="card">
              <div className="card-number">03</div>
              <h3 style={{ fontSize: 18 }}>Rakit</h3>
              <p style={{ fontSize: 14, marginTop: 8 }}>
                GitHub Actions menjalankan proyek Android WebView template,
                menaruh sumber kamu di dalamnya, lalu compile pakai Gradle.
              </p>
            </div>
            <div className="card">
              <div className="card-number">04</div>
              <h3 style={{ fontSize: 18 }}>Simpan</h3>
              <p style={{ fontSize: 14, marginTop: 8 }}>
                APK hasil build diunggah sebagai artifact/release di GitHub.
              </p>
            </div>
            <div className="card">
              <div className="card-number">05</div>
              <h3 style={{ fontSize: 18 }}>Poll</h3>
              <p style={{ fontSize: 14, marginTop: 8 }}>
                Halaman Konversi terus mengecek status build tiap beberapa
                detik lewat GitHub API.
              </p>
            </div>
            <div className="card">
              <div className="card-number">06</div>
              <h3 style={{ fontSize: 18 }}>Ambil</h3>
              <p style={{ fontSize: 14, marginTop: 8 }}>
                Begitu status "siap", tombol unduh APK muncul di halaman yang
                sama.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section" style={{ borderTop: "3px solid var(--ink)" }}>
        <div className="wrap">
          <span className="eyebrow">Batasan Yang Perlu Kamu Tahu</span>
          <h2 className="section-title">Bukan sihir, ada aturan main</h2>
          <div className="grid-2">
            <div className="card">
              <h3 style={{ fontSize: 16 }}>Waktu build</h3>
              <p style={{ fontSize: 14, marginTop: 8 }}>
                Compile Android makan waktu 2–5 menit sekali jalan, tergantung
                ukuran sumbernya. Ini wajar, bukan macet.
              </p>
            </div>
            <div className="card">
              <h3 style={{ fontSize: 16 }}>APK belum ditandatangani rilis</h3>
              <p style={{ fontSize: 14, marginTop: 8 }}>
                Secara default APK ditandatangani dengan kunci debug. Untuk
                dipublikasikan ke Play Store, kamu perlu proses signing
                sendiri dengan kunci rilis.
              </p>
            </div>
            <div className="card">
              <h3 style={{ fontSize: 16 }}>Setup sekali di awal</h3>
              <p style={{ fontSize: 14, marginTop: 8 }}>
                Kamu perlu satu repo GitHub berisi template Android + workflow
                Actions. Panduannya ada di halaman Setup.
              </p>
            </div>
            <div className="card">
              <h3 style={{ fontSize: 16 }}>Konten website tetap tanggung
                jawab kamu</h3>
              <p style={{ fontSize: 14, marginTop: 8 }}>
                ZIP2APK cuma membungkus. Pastikan kamu berhak mengemas konten
                yang kamu masukkan.
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
