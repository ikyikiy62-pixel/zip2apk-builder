import { NextResponse } from "next/server";

/**
 * Route ini memicu GitHub Actions di repo template kamu.
 * Butuh env var: GH_TOKEN, GH_OWNER, GH_REPO (lihat halaman /docs).
 *
 * Alur:
 * 1. Kalau sumbernya ZIP, file di-upload dulu ke branch sementara di repo
 *    template (lewat GitHub Contents API) supaya bisa dibaca oleh workflow.
 * 2. Kirim "repository_dispatch" event ke GitHub dengan payload berisi
 *    info sumber (url atau path zip tadi), nama aplikasi, dan package id.
 * 3. Workflow di repo template (build.yml) yang mendengarkan event ini
 *    lalu benar-benar menjalankan Gradle build.
 * 4. Frontend akan polling status build lewat /api/status.
 */

export async function POST(req) {
  const GH_TOKEN = process.env.GH_TOKEN;
  const GH_OWNER = process.env.GH_OWNER;
  const GH_REPO = process.env.GH_REPO;

  if (!GH_TOKEN || !GH_OWNER || !GH_REPO) {
    return NextResponse.json(
      {
        error:
          "Bengkel build belum dikonfigurasi. Isi GH_TOKEN, GH_OWNER, GH_REPO di Environment Variables (lihat halaman Setup)."
      },
      { status: 500 }
    );
  }

  try {
    const form = await req.formData();
    const appName = form.get("appName");
    const packageId = form.get("packageId");
    const source = form.get("source");
    const url = form.get("url");
    const file = form.get("file");

    if (!appName) {
      return NextResponse.json({ error: "Nama aplikasi wajib diisi." }, { status: 400 });
    }

    let zipPath = null;

    if (source === "zip") {
      if (!file) {
        return NextResponse.json({ error: "File ZIP wajib diupload." }, { status: 400 });
      }
      const buffer = Buffer.from(await file.arrayBuffer());
      const base64 = buffer.toString("base64");
      zipPath = `incoming/${Date.now()}-${file.name}`;

      const putRes = await fetch(
        `https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${zipPath}`,
        {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${GH_TOKEN}`,
            Accept: "application/vnd.github+json"
          },
          body: JSON.stringify({
            message: `Upload sumber untuk ${appName}`,
            content: base64
          })
        }
      );

      if (!putRes.ok) {
        const errText = await putRes.text();
        return NextResponse.json(
          { error: `Gagal upload ZIP ke GitHub: ${errText.slice(0, 200)}` },
          { status: 502 }
        );
      }
    }

    const clientPayloadId = `${Date.now()}`;

    const dispatchRes = await fetch(
      `https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/dispatches`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${GH_TOKEN}`,
          Accept: "application/vnd.github+json"
        },
        body: JSON.stringify({
          event_type: "build-apk",
          client_payload: {
            id: clientPayloadId,
            appName,
            packageId,
            source,
            url: source === "url" ? url : null,
            zipPath: source === "zip" ? zipPath : null
          }
        })
      }
    );

    if (!dispatchRes.ok) {
      const errText = await dispatchRes.text();
      return NextResponse.json(
        { error: `Gagal memicu build: ${errText.slice(0, 200)}` },
        { status: 502 }
      );
    }

    return NextResponse.json({ runId: clientPayloadId });
  } catch (err) {
    return NextResponse.json(
      { error: "Terjadi kesalahan saat memproses permintaan." },
      { status: 500 }
    );
  }
}
