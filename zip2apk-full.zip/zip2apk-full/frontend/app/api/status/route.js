import { NextResponse } from "next/server";

/**
 * Polling status build.
 * Konvensi: workflow di repo template WAJIB membuat GitHub Release
 * dengan tag "build-<id>" dan mengunggah APK sebagai asset di release
 * itu setelah build sukses. Kalau build gagal, workflow cukup biarkan
 * tidak ada release muncul, dan status di sini akan dicek lewat riwayat
 * workflow run (event repository_dispatch) untuk tahu apakah sudah gagal.
 */

export async function GET(req) {
  const GH_TOKEN = process.env.GH_TOKEN;
  const GH_OWNER = process.env.GH_OWNER;
  const GH_REPO = process.env.GH_REPO;

  if (!GH_TOKEN || !GH_OWNER || !GH_REPO) {
    return NextResponse.json(
      { status: "error", error: "Bengkel build belum dikonfigurasi." },
      { status: 500 }
    );
  }

  const { searchParams } = new URL(req.url);
  const runId = searchParams.get("runId");

  if (!runId) {
    return NextResponse.json({ status: "error", error: "runId wajib diisi." }, { status: 400 });
  }

  try {
    const tag = `build-${runId}`;

    const relRes = await fetch(
      `https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/releases/tags/${tag}`,
      {
        headers: {
          Authorization: `Bearer ${GH_TOKEN}`,
          Accept: "application/vnd.github+json"
        }
      }
    );

    if (relRes.ok) {
      const release = await relRes.json();
      const apkAsset = (release.assets || []).find((a) => a.name.endsWith(".apk"));
      if (apkAsset) {
        return NextResponse.json({
          status: "ready",
          downloadUrl: apkAsset.browser_download_url
        });
      }
      // Release ada tapi belum ada asset — masih dianggap dalam proses.
      return NextResponse.json({ status: "transit" });
    }

    // Belum ada release, cek riwayat workflow run terakhir untuk lihat
    // apakah build sudah gagal.
    const runsRes = await fetch(
      `https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/actions/runs?event=repository_dispatch&per_page=5`,
      {
        headers: {
          Authorization: `Bearer ${GH_TOKEN}`,
          Accept: "application/vnd.github+json"
        }
      }
    );

    if (runsRes.ok) {
      const runsData = await runsRes.json();
      const latest = (runsData.workflow_runs || [])[0];
      if (latest && latest.status === "completed" && latest.conclusion === "failure") {
        return NextResponse.json({
          status: "error",
          error: "Build gagal di GitHub Actions. Cek log run di repo GitHub kamu."
        });
      }
    }

    return NextResponse.json({ status: "transit" });
  } catch (err) {
    return NextResponse.json(
      { status: "error", error: "Gagal mengecek status build." },
      { status: 500 }
    );
  }
}
