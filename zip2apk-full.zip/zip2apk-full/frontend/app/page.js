export default function Home() {
  return (
    <main>
      <section className="hero">
        <div className="wrap hero-grid">
          <div>
            <span className="stamp">ZIP → APK</span>
            <h1 style={{ marginTop: 16 }}>
              Bungkus situsmu jadi aplikasi Android.
            </h1>
            <p className="hero-sub">
              Upload arsip ZIP hasil build web kamu, atau cukup tempel link
              website. Sistem membungkusnya jadi APK yang siap dipasang —
              tanpa kamu perlu install Android Studio.
            </p>
            <div className="hero-cta">
              <a href="/convert" className="btn">
                Mulai konversi
              </a>
              <a href="/how-it-works" className="btn btn-outline">
                Lihat cara kerja
              </a>
            </div>
          </div>

          <div className="hero-visual">
            <div className="line">$ sumber: https://app-kamu.com</div>
            <div className="line">$ nama paket: com.kamu.app</div>
            <div className="line">$ status: dikemas...</div>
            <div className="line">$ status: dibangun oleh runner</div>
            <div className="line ok">$ status: siap diambil ✓</div>
            <div className="line">$ file: app-release.apk (12.4 MB)</div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="wrap">
          <span className="eyebrow">Dua Cara Masuk</span>
          <h2 className="section-title">Pilih sumbernya</h2>
          <div className="grid-2">
            <div className="card">
              <div className="tag">Sumber 01</div>
              <h3 style={{ marginTop: 14, fontSize: 20 }}>Arsip ZIP</h3>
              <p style={{ marginTop: 10, fontSize: 14 }}>
                Upload hasil build statis (HTML/CSS/JS) kamu. Sistem
                menaruhnya di dalam WebView Android dan membungkusnya jadi
                APK.
              </p>
            </div>
            <div className="card">
              <div className="tag">Sumber 02</div>
              <h3 style={{ marginTop: 14, fontSize: 20 }}>Link Website</h3>
              <p style={{ marginTop: 10, fontSize: 14 }}>
                Tempel URL situs yang sudah online. APK yang dihasilkan akan
                membuka situs itu di dalam WebView, seperti aplikasi native.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section" style={{ borderTop: "3px solid var(--ink)" }}>
        <div className="wrap">
          <span className="eyebrow">Kenapa Butuh Setup Sekali</span>
          <h2 className="section-title">Apa yang terjadi di balik layar</h2>
          <div className="grid-3">
            <div className="card">
              <div className="card-number">01</div>
              <p style={{ fontSize: 14 }}>
                Kamu isi sumber (ZIP atau link) dan nama aplikasi di halaman
                Konversi.
              </p>
            </div>
            <div className="card">
              <div className="card-number">02</div>
              <p style={{ fontSize: 14 }}>
                Permintaan itu memicu proses build di GitHub Actions —
                tempat APK benar-benar dikompilasi.
              </p>
            </div>
            <div className="card">
              <div className="card-number">03</div>
              <p style={{ fontSize: 14 }}>
                Begitu build selesai, file APK muncul sebagai unduhan di
                halaman Konversi.
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
