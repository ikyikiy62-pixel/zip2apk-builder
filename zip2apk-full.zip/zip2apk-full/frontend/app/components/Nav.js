"use client";

import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/", label: "Beranda" },
  { href: "/convert", label: "Konversi" },
  { href: "/how-it-works", label: "Cara Kerja" },
  { href: "/docs", label: "Setup" }
];

export default function Nav() {
  const pathname = usePathname();

  return (
    <div className="nav">
      <div className="nav-inner">
        <a href="/" className="nav-logo">
          <span className="nav-logo-box">Z2A</span>
          ZIP2APK
        </a>
        <div className="nav-links">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className={`nav-link ${pathname === l.href ? "active" : ""}`}
            >
              {l.label}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
