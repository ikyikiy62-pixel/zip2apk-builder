"use client";

import { useState, useRef, useEffect } from "react";

export default function ConvertPage() {
  const [tab, setTab] = useState("zip");
  const [appName, setAppName] = useState("");
  const [packageId, setPackageId] = useState("");
  const [url, setUrl] = useState("");
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState(null); // null | "packed" | "transit" | "ready" | "error"
  const [error, setError] = useState("");
  const [runId, setRunId] = useState(null);
  const [downloadUrl, setDownloadUrl] = useState(null);
  const pollRef = useRef(null);

  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  function handleFileChange(e) {
    const f = e.target.files?.[0];
    if (f) setFile(f);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setDownloadUrl(null);

    if (!appName.trim()) {
      setError("Nama aplikasi wajib diisi.");
      return;
    }
    if (tab === "url" && !url.trim()) {
      setError("Link website wajib diisi.");
      return;
    }
    if (tab === "zip" && !file) {
      setError("Upload file ZIP dulu.");
      return;
    }

    setStatus("packed");

    try {
      const form = new FormData();
      form.append("appName", appName.trim());
      form.append(
        "packageId",
        packageId.trim() || `com.zip2apk.${appName.trim().toLowerCase().replace(/[^a-z0-9]/g, "")}`
      );
      form.append("source", tab);
      if (tab === "url") form.append("url", url.trim());
      if (tab === "zip") form.append("file", file);

      const res = await fetch("/api/convert", { method: "POST", body: form });
      const data = await res.json();

      if (!res.ok) {
        setStatus("error");
        setError(data.error || "Gagal memulai proses build.");
        return;
      }

      setRunId(data.runId);
      setStatus("transit");

      pollRef.current = setInterval(async () => {
        const s = await fetch(`/api/status?runId=${data.runId}`);
        const sd = await s.json();
        if (sd.status === "ready") {
          setStatus("ready");
          setDownloadUrl(sd.downloadUrl);
          clearInterval(pollRef.current);
        } else if (sd.status === "error") {
          setStatus("error");
          setError(sd.error || "Build gagal.");
          clearInterval(pollRef.current);
        }
      }, 4000);
    } catch (err) {
      setStatus("error");
      setError("Tidak bisa menghubungi server build.");
    }
  }

  return (
    <main className="section">
      <div className="wrap" style={{ maxWidth: 720 }}>
        <span className="eyebrow">Bengkel Konversi</span>
        <h1 className="section-title" style={{ fontSize: 32 }}>
          Bungkus jadi APK
        </h1>

        <div className="tabs">
          <div
            className={`tab ${tab === "zip" ? "active" : ""}`}
            onClick={() => setTab("zip")}
          >
            Arsip ZIP
          </div>
          <div
            className={`tab ${tab === "url" ? "active" : ""}`}
            onClick={() => setTab("url")}
          >
            Link Website
          </div>
        </div>

        <form className="tool-panel" onSubmit={handleSubmit}>
          <div className="field">
            <label>Nama aplikasi</label>
            <input
              type="text"
              placeholder="Contoh: Toko Kopi Saya"
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
            />
          </div>

          <div className="field">
            <label>ID paket (opsional)</label>
            <input
              type="text"
              placeholder="com.namakamu.aplikasi"
              value={packageId}
              onChange={(e) => setPackageId(e.target.value)}
            />
          </div>

          {tab === "url" ? (
            <div className="field">
              <label>Link website</label>
              <input
                type="text"
                placeholder="https://situskamu.com"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
              />
            </div>
          ) : (
            <div className="field">
              <label>Arsip ZIP</label>
              <label className={`dropzone ${file ? "has-file" : ""}`}>
                <input type="file" accept=".zip" onChange={handleFileChange} />
                {file ? (
                  <span>{file.name}</span>
                ) : (
                  <span>Klik untuk pilih file .zip</span>
                )}
              </label>
            </div>
          )}

          <button
            className="btn"
            type="submit"
            disabled={status === "packed" || status === "transit"}
          >
            {status === "transit" ? "Sedang dibangun..." : "Kirim ke bengkel"}
          </button>

          {error && <div className="error-box">{error}</div>}

          {status && status !== "error" && (
            <div className="manifest">
              <div className="manifest-row">
                <span>APLIKASI</span>
                <span>{appName || "-"}</span>
              </div>
              <div className="manifest-row">
                <span>SUMBER</span>
                <span>{tab === "zip" ? "ARSIP ZIP" : "LINK WEBSITE"}</span>
              </div>
              <div className="manifest-row">
                <span>STATUS</span>
                <span
                  className={`status-pill ${
                    status === "packed"
                      ? "packed"
                      : status === "transit"
                      ? "transit"
                      : "ready"
                  }`}
                >
                  {status === "packed" && "DIKEMAS"}
                  {status === "transit" && "DALAM PROSES BUILD"}
                  {status === "ready" && "SIAP DIAMBIL"}
                </span>
              </div>
              {downloadUrl && (
                <div style={{ marginTop: 14 }}>
                  <a className="btn" href={downloadUrl} target="_blank" rel="noreferrer">
                    Unduh APK
                  </a>
                </div>
              )}
            </div>
          )}
        </form>

        <div className="notice-box">
          Build APK berjalan lewat GitHub Actions, bukan di server ini.
          Kalau muncul pesan "belum dikonfigurasi", artinya environment
          variable GH_TOKEN dan GH_TEMPLATE_REPO belum diisi — lihat halaman
          Setup untuk langkahnya.
        </div>
      </div>
    </main>
  );
}
