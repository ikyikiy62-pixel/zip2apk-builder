export default function Docs() {
  return (
    <main className="section">
      <div className="wrap" style={{ maxWidth: 760 }}>
        <span className="stamp">Setup Sekali Di Awal</span>
        <h1 style={{ marginTop: 16, fontSize: 36 }}>Menyalakan bengkel build</h1>
        <p className="hero-sub">
          Bagian ini cuma perlu dilakukan sekali. Setelah selesai, siapa pun
          yang pakai website kamu tinggal isi form di halaman Konversi.
        </p>

        <div className="crate" style={{ marginTop: 32 }}>
          <div className="tag">Langkah 1</div>
          <h3 style={{ marginTop: 12, fontSize: 18 }}>
            Buat repo GitHub dari template
          </h3>
          <p style={{ fontSize: 14, marginTop: 8 }}>
            Ambil folder <code>github-template/</code> dari paket unduhan,
            push jadi repo baru di GitHub kamu (nama bebas, misal{" "}
            <code>zip2apk-builder</code>). Repo ini isinya proyek Android
            WebView minimal + file workflow{" "}
            <code>.github/workflows/build.yml</code> yang akan jalan tiap
            kali dipicu.
          </p>
        </div>

        <div className="crate" style={{ marginTop: 20 }}>
          <div className="tag">Langkah 2</div>
          <h3 style={{ marginTop: 12, fontSize: 18 }}>Buat Personal Access Token</h3>
          <p style={{ fontSize: 14, marginTop: 8 }}>
            Di GitHub: Settings → Developer settings → Personal access tokens
            → Fine-grained tokens. Beri akses <code>Contents: Read & Write</code>{" "}
            dan <code>Actions: Read & Write</code> khusus ke repo template
            tadi.
          </p>
        </div>

        <div className="crate" style={{ marginTop: 20 }}>
          <div className="tag">Langkah 3</div>
          <h3 style={{ marginTop: 12, fontSize: 18 }}>
            Isi Environment Variables di Vercel
          </h3>
          <p style={{ fontSize: 14, marginTop: 8 }}>
            Di project Vercel kamu, Settings → Environment Variables, isi:
          </p>
          <div className="manifest" style={{ marginTop: 12 }}>
            <div className="manifest-row">
              <span>GH_TOKEN</span>
              <span>token dari langkah 2</span>
            </div>
            <div className="manifest-row">
              <span>GH_OWNER</span>
              <span>username GitHub kamu</span>
            </div>
            <div className="manifest-row">
              <span>GH_REPO</span>
              <span>nama repo template, misal zip2apk-builder</span>
            </div>
          </div>
        </div>

        <div className="crate" style={{ marginTop: 20 }}>
          <div className="tag">Langkah 4</div>
          <h3 style={{ marginTop: 12, fontSize: 18 }}>Redeploy</h3>
          <p style={{ fontSize: 14, marginTop: 8 }}>
            Redeploy project Vercel kamu supaya environment variable baru
            terbaca. Setelah itu halaman Konversi sudah bisa memicu build
            sungguhan.
          </p>
        </div>

        <div className="notice-box" style={{ marginTop: 28 }}>
          Detail lengkap isi file workflow dan struktur proyek Android ada di{" "}
          <code>github-template/README.md</code> pada paket unduhan.
        </div>
      </div>
    </main>
  );
}
